Sample configuration files for:
```
SystemD: aliencoind.service
Upstart: aliencoind.conf
OpenRC:  aliencoind.openrc
         aliencoind.openrcconf
CentOS:  aliencoind.init
macOS:    org.aliencoin.aliencoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
